﻿using Microsoft.EntityFrameworkCore;
using Travel.Data.Entities;

namespace Travel.Data {
    public class MainDbContext : DbContext {
        public MainDbContext(DbContextOptions options) : base(options) { }

        public DbSet<ItineraryEntity> Itineraries { get; set; }
    }
}