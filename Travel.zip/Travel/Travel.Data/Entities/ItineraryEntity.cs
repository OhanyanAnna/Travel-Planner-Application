﻿namespace Travel.Data.Entities {
    public class ItineraryEntity : BaseEntity {
        public string Country { get; set; } = null!;
        public string? Region { get; set; }
        public string? City { get; set; }
        public string? Description { get; set; }
    }
}
