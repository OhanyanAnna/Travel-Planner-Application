﻿using Travel.Data.Entities;
using Travel.Data;

namespace Travel.Core.Services {
    public class ItineraryServices : IItineraryServices {
        MainDbContext context;

        public ItineraryServices(MainDbContext context) {
            this.context = context;
        }

        public ItineraryEntity? AddItinerary(string Country, string? Region, string? City, string? Description) {
            if (String.IsNullOrEmpty(Country))
            {
                return null;
            }

            ItineraryEntity it = new ItineraryEntity() {
                Country = Country,
                Region = Region,
                City = City,
                Description = Description
            };

            context.Add(it);
            context.SaveChanges();
            
            return it;
        }
        public ItineraryEntity? DeleteItinerary(int id) {
            ItineraryEntity? it = context.Itineraries.FirstOrDefault(x => x.Id == id);

            if (it == null) {
                return null;
            }

            context.Remove(it);
            context.SaveChanges();

            return it;
        }
        public ItineraryEntity? EditItinerary(int id, string? Country, string? Region, string? City, string? Description) {
            ItineraryEntity? it = context.Itineraries.FirstOrDefault(i => i.Id == id);

            if (it == null) {
                return null;
            }

            if (!String.IsNullOrEmpty(Country)) {
                it.Country = Country;
            }
            if (!String.IsNullOrEmpty(Region)) {
                it.Region = Region;
            }
            if (!String.IsNullOrEmpty(City)) {
                it.City = City;
            }
            if (!String.IsNullOrEmpty(Description)) {
                it.Description = Description;
            }

            context.Itineraries.Update(it);
            context.SaveChanges();

            return it;
        }
        public List<ItineraryEntity>? GetAll() {
            List<ItineraryEntity>? list = new List<ItineraryEntity>();

            foreach (var i in context.Itineraries)
            {
                list.Add(i);
            }

            return list;
        }
    }
}
