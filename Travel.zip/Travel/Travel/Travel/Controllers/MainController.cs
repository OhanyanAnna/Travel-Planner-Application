﻿using Microsoft.AspNetCore.Mvc;
using Travel.Data;
using Travel.Core.Services;

namespace UFAR_AO.API.Controllers {
    public class MainController : Controller {
        MainDbContext context;
        IItineraryServices services;
        public MainController(MainDbContext context, IItineraryServices services) {
            this.context = context;
            this.services = services;
        }

        [HttpPost("Add")]
        public IActionResult Add(string Country, string? Region, string? City, string? Description) {
            return Ok(services.AddItinerary(Country, Region, City, Description));
        }

        [HttpDelete("Delete")]
        public IActionResult Delete(int id) {
            return Ok(services.DeleteItinerary(id));
        }

        [HttpPost("Edit")]
        public IActionResult Edit(int id, string? Country, string? Region, string? City, string? Description) {
            return Ok(services.EditItinerary(id, Country, Region, City, Description));
        }

        [HttpGet("SeeAll")]
        public IActionResult Get() {
            return Ok(services.GetAll());
        }
    }
}
