﻿using Travel.Data.Entities;

namespace Travel.Core.Services {
    public interface IItineraryServices {
        public ItineraryEntity? AddItinerary(string Country, string? Region, string? City, string? Description);
        public ItineraryEntity? DeleteItinerary(int id);
        public ItineraryEntity? EditItinerary(int id, string? Country, string? Region, string? City, string? Description);
        public List<ItineraryEntity>? GetAll();
    }
}
